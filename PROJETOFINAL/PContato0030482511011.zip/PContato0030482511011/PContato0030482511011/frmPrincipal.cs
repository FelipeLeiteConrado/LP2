﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482511011
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=APOLO; Initial Catalog=BD;Persist Security Info=True;User ID=BD2511011;Password = FLC#12122006");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro no banco de dados." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro." + ex.Message);
            }
        }

        private void AbrirFormFilho(Form frm)
        {
            // Verifica se já existe um filho do mesmo tipo aberto
            foreach (Form f in this.MdiChildren)
            {
                if (f.GetType() == frm.GetType())
                {
                    f.Activate(); // traz pra frente
                    return;
                }
            }

            frm.MdiParent = this;
            frm.WindowState = FormWindowState.Maximized; // deixa fixo e maximizado
            frm.Show();
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormFilho(new frmContato());
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormFilho(new frmSobre());
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}