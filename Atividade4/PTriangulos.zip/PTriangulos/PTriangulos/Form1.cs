﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulos
{
    public partial class Form1 : Form
    {
        double a, b, c;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            try
            {
                Convert.ToDouble(txtValorA.Text);
                Convert.ToDouble(txtValorB.Text);
                Convert.ToDouble(txtValorC.Text);

                if (a < 0 || b < 0 || c < 0)
                    throw new Exception();

                if (a < b + c && b < a + c && c < a + b)
                {
                    if (a == b && b == c)
                    {
                        MessageBox.Show("O seu triângulo é equilátero");
                    }
                    else if (a == b || b == c || a == c)
                    {
                        MessageBox.Show("O seu triângulo é isósceles");
                    }
                    else
                    {
                        MessageBox.Show("O seu triângulo é escaleno");
                    }
                }
                else
                    MessageBox.Show("Os valores informados não formam um triângulo.");
            }
            catch
            {
                MessageBox.Show("Valores Inválidos.");
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Text = "";
            txtValorB.Text = "";
            txtValorC.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            bool conversaoBemSucedida = Double.TryParse(txtValorA.Text, out a);

            if (!conversaoBemSucedida)
                MessageBox.Show("O valor de A não é valido.");

        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            bool conversaoBemSucedida = Double.TryParse(txtValorB.Text, out b);

            if (!conversaoBemSucedida)
                MessageBox.Show("O valor de B não é valido.");
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            bool conversaoBemSucedida = Double.TryParse(txtValorC.Text, out c);

            if (!conversaoBemSucedida)
                MessageBox.Show("O valor de C não é valido.");
        }
    }
}
