﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double mediaGeral;
        double soma;
        double[,] notas = new double[5, 3];
        double[] media = new double[5];
        string aux;
        string resultado = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {


            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    bool valido = false;
                    while (!valido)
                    {
                        aux = Interaction.InputBox($"Digite a nota do professor {j + 1} para o aluno {i + 1} (0 a 10):", "Entrada de Notas");

                        if (double.TryParse(aux, out double nota) && nota >= 0 && nota <= 10)
                        {
                            notas[i, j] = nota;
                            valido = true;
                        }
                        else
                        {
                            MessageBox.Show("Nota inválida! Digite um número entre 0 e 10.");
                        }
                    }
                }
            }

            for (int i = 0; i < 5; i++)
            {
                soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    soma += notas[i, j];
                }
                media[i] = soma / 3;
            }

            for (int i = 0; i < 5; i++)
            {
                resultado = $"Aluno {i + 1}";
                for (int j = 0; j < 3; j++)
                {
                    resultado += $" Nota Professor {j + 1}: {notas[i, j]:F2}";
                }
                resultado += $" Média {media[i]:F2}";
                lbxMedias.Items.Add(resultado);
            }

            soma = 0;
            for (int i = 0; i < 5; i++)
            {
                soma += media[i];
            }
            mediaGeral = soma / 5;

            lbxMedias.Items.Add("----------------------");
            lbxMedias.Items.Add($"Média Geral Alunos: {mediaGeral:F2}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxMedias.Items.Clear();
        }
    }
}
